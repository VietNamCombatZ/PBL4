def test_imports():
    import src.config  # noqa: F401
    import src.types  # noqa: F401
    import src.net.graph  # noqa: F401
    import src.aco.solver  # noqa: F401
